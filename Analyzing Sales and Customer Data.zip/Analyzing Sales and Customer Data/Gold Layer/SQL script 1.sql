SELECT ProductKey, SUM(OrderQuantity) AS total_quantity
FROM gold.sales
GROUP BY ProductKey
ORDER BY ProductKey;

SELECT *
FROM gold.sales
WHERE StockDate < OrderDate;


